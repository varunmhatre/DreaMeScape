Thanks for downloading our font.

This is limited character demo version.
if you would like to consider using it for commercial projects. 
visit this page and buy it with full glyph set.
http://www.studiotypo.com/shop/index.php?rt=product/product&product_id=14

if you want test the full character set, visit this page.
http://www.studiotypo.com/shop/index.php?rt=product/product&product_id=14

Thanks


