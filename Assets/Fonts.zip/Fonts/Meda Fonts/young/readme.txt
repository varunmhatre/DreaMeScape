Terms of Use and License for the font Young

Designed by Wm Scott Simpson Jr, 2011
wmscottsimpsonjr.com
scott@wmscottsimpsonjr.com

This is an agreement between you, the purchaser, and Scott Simpson, the author. By downloading or installing this font you agree to these terms.

COPYRIGHT
This font is copyright 2011 Scott Simpson. You may be held legally responsible for any infringement of Scott Simpson's intellectual property rights tied to your failure to comply to any of these terms.

COMMERCIAL USE
This font is currently free for personal and commercial use, and any version obtained as free for these uses will remain so, even if future versions may be available for a fee.

REDISTRIBUTION AND MODIFICATION
You may not redistribute this font by any means, whether for free or for a fee, without permission from the author. You may not alter this font for redistribution. You may build upon individual characters for personal use.

DISCLAIMER
Scott Simpson makes no warranty of any kind, either express or implied, including but not limited to the implied warranties of merchantability and fitness for any particular purpose. Scott Simpson is not liable to you or any other person or entity for any damages arising from the use of or inability to use this font.

DURATION
This agreement is effective until terminated. This agreement will terminate automatically without notice if you fail to comply with any provision herein.

Contact Scott Simpson at scott@wmscottsimpsonjr.com for questions about this agreement.