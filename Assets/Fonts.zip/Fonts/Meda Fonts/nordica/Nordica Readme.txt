Nordica License

This font is 100% Free. You can do anything you like with it.